<?php
return array(
    'julien'  =>'kofrmjmoezhjilblfze',
    'alice'   =>'hoihfihrepoihfrrfre',
    'corentin'=>'dpihfrlkhfrehprezok'
);