# Chapter 1

Now that we know who you are[^note1], I know who I am. [I’m not a mistake!](https://www.youtube.com/watch?v=Mnb_3ibUp38) It all makes sense! In a comic, you know how you can tell who the arch-villain’s going to be? He’s the exact opposite of the hero. And most times they’re friends, like you and me! I should’ve known way back when... You know why, David? Because of the kids. They called me Mr Glass.

> Fuckin’ up the way the nigger talks. Motherfucker do that shit to me, he better paralyze my ass, ’cause I’ll kill the motherfucker, know what 

Now that there is the Tec-9, a crappy spray gun from South Miami. This gun is advertised as the most popular gun in American crime. Do you believe that shit? It actually says that in the little book that comes with it: the most popular gun in American crime. Like they’re actually proud of that shit. 

[^note1]: Now that we know who you are, I know who I am.

Look, just because I don’t be givin’ no man :
* a foot massage 
* don’t make it right 
* for Marsellus to throw Antwone 
* into a glass motherfuckin’ house


## I’m sayin’?

Look, just because I don’t be givin’ no man a foot massage don’t make it right for Marsellus to throw Antwone into a glass motherfuckin’ house, fuckin’ up the way the nigger talks. Motherfucker do that shit to me, he better paralyze my ass, ’cause I’ll kill the motherfucker, know what I’m sayin’?

Now that we know who you are, I know who I am. I’m not a mistake! It all makes sense! In a comic, you know how you can tell who the arch-villain’s going to be? He’s the exact opposite of the hero. And most times they’re friends, like you and me! I should’ve known way back when... You know why, David? Because of the kids. They called me Mr Glass.


