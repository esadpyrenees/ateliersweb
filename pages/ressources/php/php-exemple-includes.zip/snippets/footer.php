  <!-- l’emplacement du fichier js est relatif au document “maître”, pas au fichier inclus -->
  <script src="js/script.js"></script>
</body>
</html>