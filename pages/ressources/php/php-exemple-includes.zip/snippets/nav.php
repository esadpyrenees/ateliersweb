<nav>
  <a href="index.php">accueil</a>
  <a href="page2.php">page 2</a>
</nav>