# -*- coding: utf8 -*-
# déclaration de l’encodage uniquement nécessaire avec Python < 3

# Ceci est un commentaire

print("Quelques nombres simples :")
print(12)  # Ceci est un nommbre entier (int)
print(12.5)  # Ceci est un nombre décimal ou flottant (float)

print("Aditions")
print(12 + 13)  # Donne un entier
print(12 + 0.5)  # Donne un flottant
print(0.5 + 12)  # :)

print("Soustractions")
print(12 - 8)
print(12 - 25)

print("Multiplications")
print(12 * 8)
print(12 * -25)

print("Divisions")
print(12 / 2)
print(11 / 2)
print(11 // 2) # Division entière
print(11 % 2)  # Modulo (le “reste” de la division)

print("Puissances")
print(2 ** 8)
print(10 ** 2)
print(2 ** 0.5)

print("Une erreur:")
print(1 / 0) # On ne peut pas diviser par zéro…