# comparisons

# let's define some variables
a = 12
b = 20
print(a, b)

print("Est-ce que a et b sont égaux ?")
print(a == b)

print("Est-ce que a et b sont différents ? ")
print(a != b)

print("Est-ce que a est supérieur à b ?")
print(a > b)

print("Est-ce que a est inférieur à b ?")
print(a < b)

print("Est-ce que a est supérieur ou égal à b ?")
print(a >= b)

print("Est-ce que a est inférieur ou égal à b ?")
print(a <= b)

result = a < b
print("Le résultat est :")
print(result)

print("Ce résultat est une valeur 'booléenne'")
print("La valeur True :")
print(True)
print("La valeur False :")
print(False)

if a < b:
    print("a est inférieur à b")

if a > b:
    print("a est supérieur à b")

print("if/else")
if a < b:
    print("A")
else:
    print("B")

print("if/elif/else")
if a > b:
    print("A")
elif a == 12:
    print("B")
else:
    print("C")

print("if/elif/elif/.../else")
if a > b:
    print("A")
elif a == 10:
    print("B 10")
elif a == 11:
    print("B 11")
elif a == 12:
    print("B 12")
elif a == 13:
    print("B 13")
else:
    print("C")

# Logique booléenne
if a > 15 and b > 15:
    print("a et b sont supérieurs à 15")
else:
    print("L’un ou l’autre de a et b n’est pas supérieur à 15")

if a > 15 or b > 15:
    print("a OU b est supérieur à 15")
else:
    print("Ni a ni b n’est supérieur à 15")

print("Un résultat :")
print(a > 15 or b > 15)

# On peut inverser une valeur booléene
print("Pas vrai")
print(not True)
print("Pas  False")
print(not False)
print("Pas pas False")
print(not not False)
print("Pas pas pas False :)")
print(not not not False)

# On peut grouper les sous-expressions en utilisant des parenthèses:
if (a > b and b == 13) or b == 25:
    print("...")
if a > b and (b == 13 or b == 25):
    print("...")

# On peut imbriquer les parenthèses:
#if a > b and (b == 13 or (b == 25 and a == 12)):
#   ...