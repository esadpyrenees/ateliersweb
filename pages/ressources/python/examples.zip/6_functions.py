# Déclarer une fonction:
def myfunction():
    print("hello!")

# Exécuter la fonction:
myfunction()

# Une erreur commune : oublier de l’exécuter
myfunction   # les parenthèses manquent…

# Déclarer une fonction qui demande un 'argument' (ou 'paramètre')
def mysecondfunction(x, y):
    print("hello!")
    print(x, y)

# Exécuter la fonction en lui transmettant deux arguments
mysecondfunction(123, 456)

def add2numbers(x, y):
    # On peut accéder aux variables 'globales'
    print(aglobalvariable)
    result = x + y
    return result

aglobalvariable = "Salut !"
thereturnedvalue = add2numbers(1, 2)
print(thereturnedvalue)
# 'result' était un nom local au sein de la fonction 'add2number', il n’est donc pas visible à l’extérieur.
# La ligne suivante causerait une erreur :
# print(result)

def anotherfunc(x, y):
    # calling add2numbers function:
    return add2numbers(x, y)

print(anotherfunc(1, 2))