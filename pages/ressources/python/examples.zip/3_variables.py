a = 12
b = 15
c = a * b
CAP = "une chaîne"

print(c)

print(CAP)

# le nom des variables  ne peut pas commencer par un chiffre
# 1a = 12

# mais ils peuvent en contenir (ailleurs qu’au début)
a1 = 12

# Les titrets bas, ou underscores sont permis:
_a = 12
a_ = 13

# En Python, tout est un objet. On peut “re-lier” le nom 'a' à un nouvel objet :
a = a + 12

# Le nom des variables est sensible à la casse
# Ainsi,
x = 12
# est une variable différente de
X = 13
print(x)
print(X)

y = 102
# Ceci produit donc une erreur
print(Y)