from random import random, randint
# En python, certains modules (la plupart) doivent être importés explicitement
# Drawbot en intègre de nombreux par défaut (dont random et randint)

# La fonction random() retourne un nombre pseudo-aléatoire entre zéro et un
print("Un nombre aléatoire entre 0.0 et 1.0")
print(random())

# La fonction randint() retourne un nombre pseudo-aléatoire dans les limites qu’on lui donne
print("Un nombre aléatoire entre 0 et 4")
print(randint(0, 4))
print("Un nombre aléatoire entre 10 and 20")
print(randint(10, 20))

# Utiliser un nombre aléatoire pour faire des choses différentes
# things.
print("Choisit aléatoirement entre A et B, 6 fois")
for i in range(6):
    if random() > 0.5:
        print("A")
    else:
        print("B")