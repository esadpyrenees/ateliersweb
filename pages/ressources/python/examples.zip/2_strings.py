print('Ceci est une "chaîne de caractères"')
print("Ceci est une 'chaîne de caractères'")
print("Ceci est une \"chaîne de caractères\"") # Les caractères délimiteurs sont “échappés”

print("une chaîne de caractères, " + "une autre chaîne de caractères")

a = "une chaîne"
b = "une autre chaîne"

print(a + " " + b)

print("Dix " * 10)

print("Les caractères non-ascii devraient fonctionner :")
print("Åbenrå © Ђ ק")
print("Et maintenant, une erreur :")
print("many " * 10.0)
# la multiplication de chaînes de caractères 
# exige un nombre entier ; un flottant qui se trouverait  
# être un nombre entier ne fonctionne pas