# Voici une liste ('list' – équivalent d’array dans d’autres languages)
alist = [1, -2, "abcdefg", 4, 50]
print(alist)
alist.append(1234)
print(alist)

# Récupérer un élément d’une liste:
print(alist[0])  # le premier élément
print(alist[1])  # le second

# les nombres négatifs permettent de parcourir la liste depuis la fin
print(alist[-1])  # le dernier élément
print(alist[-2])  # l’avant-dernier

print("nested lists:")
print([1, 2, 3, ["a", "b", "c"]])
print([1, 2, 3, ["a", ["deeper"]]])

# Attention : assigner une liste à un autre nom de variable 
# n’en crée pas une copie. On crée seulement une autre référence au même objet
anotherlist = alist
anotherlist.append(-9999)
print(anotherlist)
print(alist)
acopy = list(alist)
acopy.append(9999)
print(acopy)
print(alist)

# Les chaînes sont aussi des séquences qui peuvent être parcourues comme des listes
astring = "abcdefg"
print(astring[2])
print(astring[-1])  # depuis la fin

print("Récupérer des “tranches” ('slices') d’une liste")
print(alist)
print(alist[2:5])

# `range` est une fonction native qui permet de créer des listes à partir de nombres 
print(range(10))  # de 0 à 10 (n’inclue pas 10!)
print(range(5, 10))  # de 5 à 10 (n’inclue pas 10!)
print(range(1, 19, 3)) # de 1 à 19, par pas de 3

