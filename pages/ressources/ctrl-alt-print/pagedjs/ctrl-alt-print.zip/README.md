# Ctrl + alt + print

A server is required for paged.js to run. If python is installed, cd to this directory `cd path/to/this/project/` then run `python3 -m http.server` otherwise look at [npm serve](https://www.npmjs.com/package/serve)
